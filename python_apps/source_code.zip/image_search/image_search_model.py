#!/usr/bin/env python3
"""
Image search model for CIFAR-10 dataset using PySpark and PyTorch
"""

import os
import io
import numpy as np
import torch
import torchvision.models as models
import torchvision.transforms as transforms
import torchvision.datasets as datasets
from PIL import Image
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf, col, lit
from pyspark.sql.types import ArrayType, FloatType, IntegerType, StringType, BinaryType
import subprocess
import pandas as pd
from py4j.protocol import Py4JNetworkError

# CIFAR-10 class names for reference
CIFAR10_CLASSES = [
    'airplane', 'automobile', 'bird', 'cat', 'deer',
    'dog', 'frog', 'horse', 'ship', 'truck'
]

# Set environment variables for PySpark to use Python 3.10
os.environ['PYSPARK_PYTHON'] = '/usr/bin/python3.10'
os.environ['PYSPARK_DRIVER_PYTHON'] = '/usr/bin/python3.10'

def extract_features(image_bytes):
    """
    Extract feature vector from image bytes using ResNet18

    This function is defined at the module level to avoid serialization issues with PySpark.

    Args:
        image_bytes: Image as bytes

    Returns:
        Feature vector as list
    """
    try:
        # Import libraries inside the function to ensure they're available on worker nodes
        import torch
        import torchvision.models as models
        import torchvision.transforms as transforms
        from PIL import Image
        import io
        import numpy as np

        # Load pre-trained ResNet model
        model = models.resnet18(weights='DEFAULT')
        model.eval()

        # Define image transformation pipeline
        transform = transforms.Compose([
            transforms.Resize(224),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                std=[0.229, 0.224, 0.225])
        ])

        # Convert bytes to PIL Image
        image = Image.open(io.BytesIO(image_bytes)).convert("RGB")

        # Apply transformations and create batch dimension
        tensor = transform(image).unsqueeze(0)

        # Extract features (without gradients for efficiency)
        with torch.no_grad():
            # Get the features before the final classification layer
            features = model(tensor)
            # Use average pooling to get a compact representation
            features = torch.nn.functional.adaptive_avg_pool2d(features, (1, 1))
            features = features.reshape(features.size(0), -1)

        # Convert to list for Spark UDF compatibility
        return features.squeeze().numpy().tolist()
    except Exception as e:
        print(f"Error processing image: {e}")
        # Return zero vector in case of error
        return [0.0] * 512  # ResNet18 feature size

def is_hdfs_available():
    try:
        subprocess.check_output(["hdfs", "dfs", "-ls", "/"], stderr=subprocess.STDOUT)
        return True
    except subprocess.CalledProcessError:
        return False

def create_spark_session():
    """
    Create and configure a new Spark session with proper error handling
    """
    try:
        import os
        # Get the current directory of the script
        current_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Create a new session connected to the external Spark cluster
        spark = SparkSession.builder \
            .appName("CIFAR10-Image-Search") \
            .master("spark://spark-master:7077") \
            .config("spark.driver.host", "custom-hadoop") \
            .config("spark.driver.memory", "4g") \
            .config("spark.executor.memory", "4g") \
            .config("spark.sql.shuffle.partitions", "10") \
            .config("spark.default.parallelism", "10") \
            .config("spark.hadoop.fs.defaultFS", "hdfs://custom-hadoop:9000") \
            .config("spark.driver.extraJavaOptions", "-XX:+UseG1GC") \
            .config("spark.executor.extraJavaOptions", "-XX:+UseG1GC") \
            .config("spark.executor.extraClassPath", "/opt/hadoop/share/hadoop/common/lib/*:/opt/hadoop/share/hadoop/common/*:/opt/hadoop/share/hadoop/hdfs/*:/opt/hadoop/share/hadoop/hdfs/lib/*") \
            .config("spark.driver.bindAddress", "0.0.0.0") \
            .config("spark.network.timeout", "600s") \
            .config("spark.python.worker.reuse", "true") \
            .config("spark.submit.pyFiles", current_dir) \
            .config("spark.executorEnv.PYTHONPATH", current_dir) \
            .config("spark.files", current_dir) \
            .getOrCreate()
            
        # Set log level to ERROR to reduce noise
        spark.sparkContext.setLogLevel("ERROR")
        
        return spark
    except Exception as e:
        print(f"Error creating Spark session: {str(e)}")
        raise

def process_cifar10_with_spark(output_path="/hadoop_lancedb_data/cifar10_embeddings.parquet",
                              max_train=1000, max_test=100):
    """
    Process CIFAR-10 dataset using PySpark and save embeddings.

    Args:
        output_path: Path to save the embeddings (will attempt HDFS first, then local).
        max_train: Maximum number of training images to process.
        max_test: Maximum number of test images to process.

    Returns:
        Path to the saved embeddings.
    """
    spark = None
    output_df = None
    try:
        # Initialize Spark with Hadoop configuration
        print("Initializing Spark with Hadoop configuration...")
        spark = SparkSession.builder \
            .appName("CIFAR10-Embedding") \
            .master("spark://172.18.0.2:7077") \
            .config("spark.hadoop.fs.defaultFS", "hdfs://localhost:9000") \
            .config("spark.executor.memory", "2g") \
            .config("spark.driver.memory", "2g") \
            .config("spark.pyspark.python", "/usr/bin/python3.10") \
            .config("spark.submit.pyFiles", "/home/hadoop/python_apps/image_search/*.py") \
            .config("spark.executorEnv.PYTHONPATH", "/home/hadoop/python_apps:/home/hadoop/python_apps/image_search") \
            .getOrCreate()

        # Set log level to reduce verbosity
        spark.sparkContext.setLogLevel("WARN")

        print("Loading CIFAR-10 dataset...")
        # Download CIFAR-10 dataset (this will be done on the driver)
        cifar10_train = datasets.CIFAR10(root='./data', train=True, download=True)
        cifar10_test = datasets.CIFAR10(root='./data', train=False, download=True)

        # Prepare data for Spark processing
        print("Preparing data for Spark processing...")
        train_data = []
        for i, (image, label) in enumerate(cifar10_train):
            if i >= max_train:
                break

            # Convert PIL Image to bytes
            img_byte_arr = io.BytesIO()
            image.save(img_byte_arr, format='PNG')
            img_bytes = img_byte_arr.getvalue()

            train_data.append((i, img_bytes, int(label), CIFAR10_CLASSES[label], 'train'))

            if (i + 1) % 100 == 0:
                print(f"Prepared {i + 1} training images")

        test_data = []
        for i, (image, label) in enumerate(cifar10_test):
            if i >= max_test:
                break

            # Convert PIL Image to bytes
            img_byte_arr = io.BytesIO()
            image.save(img_byte_arr, format='PNG')
            img_bytes = img_byte_arr.getvalue()

            test_data.append((i + 10000, img_bytes, int(label), CIFAR10_CLASSES[label], 'test'))

            if (i + 1) % 20 == 0:
                print(f"Prepared {i + 1} test images")

        # Combine train and test data
        all_data = train_data + test_data

        # Create DataFrame from the data
        print("Creating Spark DataFrame...")
        df = spark.createDataFrame(
            all_data,
            ["id", "image_bytes", "label_id", "label_name", "split"]
        )

        # Create and register UDF for feature extraction
        print("Creating feature extraction UDF...")
        extract_features_udf = udf(extract_features, ArrayType(FloatType()))

        # Extract features using the UDF
        print("Extracting features from images...")
        df_with_features = df.withColumn("embedding", extract_features_udf(col("image_bytes")))

        # Select relevant columns for output
        output_df = df_with_features.select(
            "id", "label_id", "label_name", "split", "embedding"
        )

        # Show sample of the data
        print("Sample of processed data:")
        output_df.limit(5).select("id", "label_id", "label_name", "split").show()

        # Attempt to save to HDFS
        if is_hdfs_available():
            print(f"Attempting to save embeddings to HDFS at {output_path}")
            try:
                output_df.write.mode("overwrite").parquet(output_path)
                print(f"Successfully saved embeddings to HDFS at {output_path}")
                return output_path
            except Exception as hdfs_error:
                print(f"Error saving to HDFS: {hdfs_error}")
                print("Falling back to local filesystem")
        else:
            print("HDFS not available, falling back to local filesystem.")

        # Save locally if HDFS is not available or saving to HDFS failed
        local_path = "/tmp/cifar10_embeddings.parquet"
        pandas_df = output_df.toPandas()
        pandas_df.to_parquet(local_path)
        print(f"Saved embeddings locally at {local_path}")
        return local_path

    except Py4JNetworkError as e:
        print(f"Py4J network error occurred: {e}")
        local_path = "/tmp/cifar10_embeddings_fallback.parquet"
        if output_df is not None:
            pandas_df = output_df.toPandas()
            pandas_df.to_parquet(local_path)
            print(f"Saved embeddings locally due to network error: {local_path}")
            return local_path
        else:
            print("DataFrame was not created before network error.")
            return None
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        return None
    finally:
        try:
            # Stop Spark session gracefully
            if spark is not None:
                spark.stop()
        except Exception as e:
            print(f"Warning: Error stopping Spark session: {str(e)}")
        print("Spark session stopped.")

if __name__ == "__main__":
    process_cifar10_with_spark()
